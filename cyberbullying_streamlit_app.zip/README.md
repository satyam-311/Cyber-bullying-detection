
# Cyberbullying Detection Web App 🚨

This Streamlit app allows users to upload a dataset containing text (headlines) and labels, trains a model using TF-IDF and LinearSVC, and shows model performance metrics.

## How to Use
1. Upload a CSV with `headline` and `label` columns.
2. The app will clean, vectorize, train, and evaluate.
3. Get a detailed classification report and visualizations.

## Deploy on Streamlit Cloud
Just clone this repo and deploy via https://streamlit.io/cloud.
